Helper functions of `R`

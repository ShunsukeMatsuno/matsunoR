`%+%` <- function(s1, s2){
  return(paste0(s1, s2))
}